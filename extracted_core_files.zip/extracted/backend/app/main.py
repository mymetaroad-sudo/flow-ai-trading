from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import Session
from app.api.routes import router
from app.api.settings_routes import router as settings_router
from app.api.analysis_routes import router as analysis_router
from app.api.connection_log_routes import router as conn_log_router
from app.api.trade_log_routes import router as trade_log_router   # ← 추가
from app.db.database import engine, init_db
from app.services.bootstrap import seed_data


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    with Session(engine) as session:
        seed_data(session)
    yield


app = FastAPI(
    title="Roadflow AI Lite V1",
    version="0.3.0",
    lifespan=lifespan,
)

# H07 수정: CORS 로컬 전용 제한
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
        "app://.",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api")
app.include_router(settings_router, prefix="/api")
app.include_router(analysis_router, prefix="/api")
app.include_router(conn_log_router, prefix="/api")
app.include_router(trade_log_router, prefix="/api")   # ← 추가
