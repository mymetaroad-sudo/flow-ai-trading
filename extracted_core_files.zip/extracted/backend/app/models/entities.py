from __future__ import annotations
from datetime import datetime
from typing import Optional
from sqlmodel import SQLModel, Field


class Recommendation(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    code: str
    name: str
    theme: str
    rank: int
    final_score: float
    # L01 수정: FinalScore 전체 항목 저장
    base_score: float = 0.0
    theme_score: float = 0.0
    leader_score: float = 0.0
    expansion_score: float = 0.0
    preopen_score: float = 0.0
    risk_penalty: float = 0.0
    market_score: float = 0.0
    preopen_status: str = "WATCH"
    is_alternative: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Position(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    code: str
    name: str
    quantity: int
    avg_price: float
    current_price: float
    stop_loss_price: float
    trailing_guard_price: float
    trailing_peak_pct: float = 0.0
    status: str = "READY"
    pnl_percent: float = 0.0
    split_stage: int = 0
    # L02 수정: ImpactRatio용 거래대금, 잔류 분석
    daily_volume: int = 0
    close_decision: str = ""
    close_reason: str = ""
    closed_at: Optional[datetime] = None
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class OrderQueueItem(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    priority: int
    order_kind: str
    code: str
    qty: int
    order_type: str
    status: str = "QUEUED"
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ScoreAdjustmentProposal(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    field_name: str
    current_value: float
    proposed_value: float
    reason: str
    decision: str = "PENDING"
    created_at: datetime = Field(default_factory=datetime.utcnow)


# H05 신규: 사후 분석용 판정 로그 (Rev5 섹션 18)
class DecisionLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    session_date: str
    stock_code: str
    event_type: str          # RECOMMEND / BUY / SELL_STOP / SELL_TRAIL / SELL_SPLIT / SELL_EMERGENCY / REJECT
    event_time: datetime = Field(default_factory=datetime.utcnow)
    final_score: float = 0.0
    score_base: float = 0.0
    score_theme: float = 0.0
    score_leader: float = 0.0
    score_expansion: float = 0.0
    score_preopen: float = 0.0
    score_penalty: float = 0.0
    go_watch_reject: str = ""
    gwr_reason: str = ""
    bid1_price: int = 0
    ask1_price: int = 0
    bid1_qty: int = 0
    filled_price: float = 0.0
    slippage_pct: float = 0.0
    sell_trigger: str = ""
    is_manual: bool = False
    market_score: float = 0.0
    cash_ratio_applied: float = 0.0


# H06 신규: 계좌 단위 일일 손실 한도 (Rev5 섹션 17)
class DailyRiskState(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    trade_date: str
    realized_loss_pct: float = 0.0
    consecutive_stops: int = 0
    emergency_triggered: bool = False
    buy_blocked: bool = False
    block_reason: str = ""
    reset_at: Optional[datetime] = None
