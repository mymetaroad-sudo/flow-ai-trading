from __future__ import annotations
from typing import Any


def _kospi_rate_to_score(rate: float) -> float:
    if rate >= 0.5: return 30.0
    elif rate >= 0.0: return 15.0
    else: return 0.0


def _kosdaq_rate_to_score(rate: float) -> float:
    if rate >= 0.5: return 20.0
    elif rate >= 0.0: return 10.0
    else: return 0.0


def calc_market_score(
    kospi_rate: float = 0.0,
    kosdaq_rate: float = 0.0,
    rising_ratio: float = 0.5,
    volume_ratio: float = 1.0,
) -> float:
    """MarketScore 계산 (Rev5 설계서 섹션 6.1)"""
    k = _kospi_rate_to_score(kospi_rate)
    d = _kosdaq_rate_to_score(kosdaq_rate)
    r = min(rising_ratio, 1.0) * 30.0
    v = 20.0 if volume_ratio >= 2.0 else (10.0 if volume_ratio >= 1.5 else 0.0)
    return round(k + d + r + v, 2)


def market_score_to_cash_ratio(market_score: float) -> int:
    """MarketScore → 현금 비중 % (섹션 6.2)"""
    if market_score >= 80: return 10
    elif market_score >= 65: return 20
    elif market_score >= 50: return 30
    else: return 50


def get_market_summary() -> dict[str, Any]:
    """
    실제 시세 연동 전 단계 — 어댑터에서 지수 수신 시 이 함수를 대체.
    현재는 샘플 데이터 반환.
    TODO: adapter.get_index_rate("001") 등으로 실 데이터 수신
    """
    kospi_rate = 0.42
    kosdaq_rate = 0.61
    rising_ratio = 0.58
    volume_ratio = 1.35

    ms = calc_market_score(kospi_rate, kosdaq_rate, rising_ratio, volume_ratio)
    cash_ratio = market_score_to_cash_ratio(ms)
    invest_ratio = 100 - cash_ratio

    return {
        "marketScore": ms,
        "cashRatio": cash_ratio,
        "allocation": {
            "rank1": round(invest_ratio * 0.37),
            "rank2": round(invest_ratio * 0.27),
            "rank3": round(invest_ratio * 0.22),
            "rank4": round(invest_ratio * 0.14),
        },
        "riskMode": (
            "RISK_ON" if ms >= 80
            else ("NEUTRAL" if ms >= 50 else "RISK_OFF")
        ),
        "scanCompletedAt": "16:52:10",
        "kospiRate": kospi_rate,
        "kosdaqRate": kosdaq_rate,
    }
