from __future__ import annotations
import asyncio
import logging
from datetime import date
from sqlmodel import Session, select
from app.adapter.kiwoom.factory import get_broker_adapter
from app.models.entities import OrderQueueItem, DailyRiskState

logger = logging.getLogger(__name__)

# C06 수정: 전역 잠금으로 동시 주문 방지
_order_lock = asyncio.Lock()


def _get_or_create_risk_state(session: Session) -> DailyRiskState:
    today = str(date.today())
    state = session.exec(
        select(DailyRiskState).where(DailyRiskState.trade_date == today)
    ).first()
    if not state:
        state = DailyRiskState(trade_date=today)
        session.add(state)
        session.commit()
        session.refresh(state)
    return state


async def process_next_order(session: Session) -> dict:
    """C06 수정: asyncio.Lock으로 직렬 처리 보장 + 400ms 딜레이"""
    async with _order_lock:
        item = session.exec(
            select(OrderQueueItem)
            .where(OrderQueueItem.status == "QUEUED")
            .order_by(OrderQueueItem.priority, OrderQueueItem.created_at)
        ).first()

        if not item:
            return {"processed": False, "message": "처리할 주문이 없습니다."}

        # 매수 주문이면 일일 손실 한도·비상탈출 차단 확인
        if item.order_kind == "BUY":
            risk = _get_or_create_risk_state(session)
            if risk.buy_blocked or risk.emergency_triggered:
                return {
                    "processed": False,
                    "message": f"매수 차단: {risk.block_reason or '비상탈출 발동'}",
                }

        adapter = get_broker_adapter()
        if item.order_kind == "BUY":
            result = adapter.send_manual_buy(code=item.code, qty=item.qty)
        else:
            result = adapter.send_sell(
                code=item.code, qty=item.qty, order_type=item.order_type
            )

        item.status = "SENT" if result.get("ok") else "FAILED"
        session.add(item)
        session.commit()
        session.refresh(item)

        # 400ms 딜레이 (키움 주문 간 충돌 방지)
        await asyncio.sleep(0.4)

        return {
            "processed": True,
            "item_id": item.id,
            "result": result,
            "queue_status": item.status,
        }


def process_next_order_sync(session: Session) -> dict:
    """동기 버전 (FastAPI 동기 엔드포인트용)"""
    item = session.exec(
        select(OrderQueueItem)
        .where(OrderQueueItem.status == "QUEUED")
        .order_by(OrderQueueItem.priority, OrderQueueItem.created_at)
    ).first()

    if not item:
        return {"processed": False, "message": "처리할 주문이 없습니다."}

    if item.order_kind == "BUY":
        risk = _get_or_create_risk_state(session)
        if risk.buy_blocked or risk.emergency_triggered:
            return {"processed": False, "message": f"매수 차단: {risk.block_reason}"}

    adapter = get_broker_adapter()
    if item.order_kind == "BUY":
        result = adapter.send_manual_buy(code=item.code, qty=item.qty)
    else:
        result = adapter.send_sell(code=item.code, qty=item.qty, order_type=item.order_type)

    item.status = "SENT" if result.get("ok") else "FAILED"
    session.add(item)
    session.commit()
    session.refresh(item)
    return {"processed": True, "item_id": item.id, "result": result, "queue_status": item.status}
