"""
trade_log_routes.py
- GET  /api/trade-logs       : 매수/매도 실현 이력 (최근 30건)
- GET  /api/asset-summary    : 자산 현황 (총평가금액, 현금, 실현손익 등)
"""

from fastapi import APIRouter
from sqlmodel import Session, select, desc
from app.db.database import engine
from app.db.models import DecisionLog, Position
from typing import List
from datetime import datetime

router = APIRouter()


# ── 매수/매도 실현 이력 ──────────────────────────────────────────
@router.get("/trade-logs")
def get_trade_logs():
    """
    DecisionLog 테이블에서 BUY / SELL 이벤트만 뽑아서 반환.
    실제 체결가(filled_price), 실현손익(pnl), 수익률(pnl_pct) 포함.
    """
    with Session(engine) as session:
        logs = session.exec(
            select(DecisionLog)
            .where(DecisionLog.event_type.in_(["BUY", "SELL", "SELL_STOP", "SELL_TRAIL", "SELL_SPLIT"]))
            .order_by(desc(DecisionLog.event_time))
            .limit(30)
        ).all()

        result = []
        for log in logs:
            result.append({
                "time": log.event_time.isoformat() if isinstance(log.event_time, datetime) else str(log.event_time),
                "code": log.stock_code,
                "name": log.stock_name or log.stock_code,
                "type": _type_label(log.event_type),
                "qty": log.qty or 0,
                "price": log.filled_price or log.entry_price or 0,
                "pnl": log.realized_pnl,
                "pnl_pct": log.pnl_pct,
                "is_manual": log.is_manual,
            })
        return result


def _type_label(event_type: str) -> str:
    mapping = {
        "BUY": "매수",
        "SELL": "매도",
        "SELL_STOP": "손절매도",
        "SELL_TRAIL": "트레일매도",
        "SELL_SPLIT": "분할매도",
    }
    return mapping.get(event_type, event_type)


# ── 자산 현황 ────────────────────────────────────────────────────
@router.get("/asset-summary")
def get_asset_summary():
    """
    보유 포지션 기반으로 자산 현황 계산:
    - total_value    : 총 평가금액 (현금 + 주식 평가금액)
    - cash           : 남은 현금
    - stock_value    : 주식 평가금액
    - realized_pnl   : 당일 누적 실현손익
    - unrealized_pnl : 현재 평가손익 (미실현)
    - positions      : 종목별 비중 정보
    """
    with Session(engine) as session:
        positions = session.exec(select(Position)).all()

        # 주식 평가금액
        stock_value = sum(
            (pos.current_price or pos.avg_price or 0) * (pos.quantity or 0)
            for pos in positions
        )

        # 미실현 손익
        unrealized_pnl = sum(
            ((pos.current_price or pos.avg_price or 0) - (pos.avg_price or 0)) * (pos.quantity or 0)
            for pos in positions
        )

        # 당일 실현손익 (DecisionLog SELL 합산)
        today = datetime.now().date()
        sell_logs = session.exec(
            select(DecisionLog)
            .where(DecisionLog.event_type.in_(["SELL", "SELL_STOP", "SELL_TRAIL", "SELL_SPLIT"]))
        ).all()

        realized_pnl = sum(
            (log.realized_pnl or 0)
            for log in sell_logs
            if log.event_time and (
                log.event_time.date() == today
                if isinstance(log.event_time, datetime)
                else True
            )
        )

        # 현금은 summary에서 가져오거나 기본값
        # 실제 구현 시 Settings 또는 별도 Asset 테이블에서 가져와야 함
        # 여기서는 total_capital - stock_value 로 추정
        try:
            from app.db.models import Settings
            settings = session.exec(select(Settings)).first()
            total_capital = getattr(settings, 'total_capital', 300_000_000) or 300_000_000
        except Exception:
            total_capital = 300_000_000

        cash = total_capital - stock_value
        total_value = cash + stock_value

        return {
            "total_value": int(total_value),
            "cash": int(max(cash, 0)),
            "stock_value": int(stock_value),
            "realized_pnl": int(realized_pnl),
            "unrealized_pnl": int(unrealized_pnl),
            "total_capital": int(total_capital),
            "cash_ratio": round(cash / total_value * 100, 1) if total_value > 0 else 100,
            "positions": [
                {
                    "code": pos.code,
                    "name": pos.name,
                    "qty": pos.quantity,
                    "avg_price": pos.avg_price,
                    "current_price": pos.current_price or pos.avg_price,
                    "value": int((pos.current_price or pos.avg_price or 0) * (pos.quantity or 0)),
                    "pnl_pct": pos.pnl_percent if hasattr(pos, 'pnl_percent') else 0,
                }
                for pos in positions
            ]
        }
